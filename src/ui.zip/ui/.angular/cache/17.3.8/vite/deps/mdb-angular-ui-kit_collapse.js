import {
  MdbCollapseDirective,
  MdbCollapseModule
} from "./chunk-ZCSSI6QH.js";
import "./chunk-DHH25WY3.js";
export {
  MdbCollapseDirective,
  MdbCollapseModule
};
//# sourceMappingURL=mdb-angular-ui-kit_collapse.js.map
